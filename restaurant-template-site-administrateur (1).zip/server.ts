import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import nodemailer from "nodemailer";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Reservation API
  app.post("/api/reserve", async (req, res) => {
    const { name, email, date, time, guests, notes } = req.body;

    // 1. Validate Opening Hours
    // Parse date manually to avoid timezone shifts (YYYY-MM-DD)
    const [year, month, day] = date.split("-").map(Number);
    const reservationDate = new Date(year, month - 1, day);
    const dayOfWeek = reservationDate.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
    
    // Monday is 1. If day is 1, it's closed.
    if (dayOfWeek === 1) {
      return res.status(400).json({ error: "Le restaurant est fermé le lundi." });
    }

    const [hours, minutes] = time.split(":").map(Number);
    const timeInMinutes = hours * 60 + minutes;

    const lunchStart = 12 * 60;
    const lunchEnd = 14 * 60 + 30;
    const dinnerStart = 19 * 60;
    const dinnerEnd = 22 * 60 + 30;

    const isLunch = timeInMinutes >= lunchStart && timeInMinutes <= lunchEnd;
    const isDinner = timeInMinutes >= dinnerStart && timeInMinutes <= dinnerEnd;

    if (!isLunch && !isDinner) {
      return res.status(400).json({ 
        error: "Nous sommes ouverts de 12h00 à 14h30 et de 19h00 à 22h30. Veuillez choisir un créneau valide." 
      });
    }

    // 2. Send Email
    try {
      const smtpUser = process.env.SMTP_USER;
      const smtpPass = process.env.SMTP_PASS;
      const smtpHost = process.env.SMTP_HOST || "smtp.ethereal.email";
      const smtpPort = Number(process.env.SMTP_PORT) || 587;

      const mailOptions = {
        from: '"La Piazza Reservation" <noreply@lapiazza.fr>',
        to: "durantadja@gmail.com",
        subject: `Nouvelle réservation - ${name}`,
        text: `
          Nouvelle réservation reçue :
          Nom : ${name}
          Email : ${email}
          Date : ${date}
          Heure : ${time}
          Convives : ${guests}
          Notes : ${notes || "Aucune"}
        `,
        html: `
          <h3>Nouvelle réservation reçue</h3>
          <p><strong>Nom :</strong> ${name}</p>
          <p><strong>Email :</strong> ${email}</p>
          <p><strong>Date :</strong> ${date}</p>
          <p><strong>Heure :</strong> ${time}</p>
          <p><strong>Convives :</strong> ${guests}</p>
          <p><strong>Notes :</strong> ${notes || "Aucune"}</p>
        `,
      };

      if (smtpUser && smtpPass) {
        const transporter = nodemailer.createTransport({
          host: smtpHost,
          port: smtpPort,
          secure: smtpPort === 465,
          auth: {
            user: smtpUser,
            pass: smtpPass,
          },
          // Add timeout and connection settings to prevent "Unexpected socket close"
          connectionTimeout: 10000,
          greetingTimeout: 10000,
          socketTimeout: 10000,
        });

        await transporter.sendMail(mailOptions);
        console.log(`Email sent successfully to durantadja@gmail.com for ${name}`);
      } else {
        // Fallback for development/preview when credentials are not yet set
        console.log("--- SMTP NOT CONFIGURED (LOGGING RESERVATION) ---");
        console.log("To: durantadja@gmail.com");
        console.log("Subject:", mailOptions.subject);
        console.log("Content:", mailOptions.text);
        console.log("-------------------------------------------------");
      }

      res.json({ success: true, message: "Réservation enregistrée." });
    } catch (error) {
      console.error("Email error:", error);
      // We still return success to the user because the reservation is valid, 
      // but we log the email failure for the admin.
      res.json({ 
        success: true, 
        message: "Réservation enregistrée (Note: Problème technique avec l'envoi de l'email de notification)." 
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production" && !process.env.VERCEL) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else if (!process.env.VERCEL) {
    // Only serve static files if NOT on Vercel (Vercel handles this via vercel.json)
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  return app;
}

const appPromise = startServer();
export default appPromise;
