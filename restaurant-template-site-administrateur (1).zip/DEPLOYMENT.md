# Guide de Déploiement Indépendant

Ce projet est une application React moderne construite avec Vite. Vous pouvez l'héberger sur n'importe quel service d'hébergement web (Vercel, Netlify, Firebase Hosting, etc.) en dehors de AI Studio.

## 1. Exporter le code
Dans AI Studio, allez dans les **Réglages** (icône engrenage) et choisissez **Export to GitHub** ou **Download ZIP**.

## 2. Configuration Firebase
Le site utilise Firebase pour stocker les menus, les commandes et les réservations.
1. Créez un projet sur [console.firebase.google.com](https://console.firebase.google.com).
2. Activez **Firestore Database** et **Authentication** (Google Login).
3. Copiez votre configuration Firebase dans un fichier `.env` à la racine de votre projet :

```env
VITE_FIREBASE_API_KEY=votre_cle
VITE_FIREBASE_AUTH_DOMAIN=votre_projet.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=votre_projet
VITE_FIREBASE_STORAGE_BUCKET=votre_projet.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=votre_id
VITE_FIREBASE_APP_ID=votre_app_id
GEMINI_API_KEY=votre_cle_gemini (optionnel pour l'IA)
```

## 3. Déploiement d'un site dédié (Standalone / Domaine Custom)
Il y a deux façons de lier un restaurant à un domaine spécifique :

### Option A : Via la Plateforme (Recommandé)
1. En tant que **Super Admin**, allez sur la page `/admin`.
2. Dans la liste des restaurants, cliquez sur **MODIFIER** à côté de "Domaine".
3. Entrez le domaine (ex: `www.monrestaurant.fr`).
4. Une fois le domaine configuré sur votre hébergeur (Vercel/Netlify), le site détectera automatiquement le restaurant correspondant.

### Option B : Via Variable d'Environnement
Si vous voulez forcer un déploiement spécifique pour un restaurant :
1. Identifiez le "slug" du restaurant (ex: `la-trattoria`).
2. Ajoutez cette variable dans votre `.env` :
   ```env
   VITE_STANDALONE_RESTAURANT_SLUG=la-trattoria
   ```
3. Une fois cette variable définie, la page d'accueil de votre site sera directement celle du restaurant, et non la plateforme de création.

## 4. Hébergement sur Vercel ou Netlify (Recommandé)
1. Connectez votre dépôt GitHub à Vercel ou Netlify.
2. Configurez les variables d'environnement (voir étape 2).
3. **Important** : Comme c'est une application Single Page (SPA), configurez les redirections pour que toutes les pages pointent vers `index.html`.
   - **Vercel** : Créez un fichier `vercel.json` :
     ```json
     {
       "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
     }
     ```
   - **Netlify** : Créez un fichier `_redirects` dans le dossier `public` :
     ```
     /* /index.html 200
     ```

## 5. Build de production
Pour générer les fichiers prêts à être mis en ligne manuellement :
```bash
npm install
npm run build
```
Les fichiers se trouveront dans le dossier `dist/`.
