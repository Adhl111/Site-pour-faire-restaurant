import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Utensils, ShieldCheck, Store, ArrowRight, LogOut, LayoutDashboard } from 'lucide-react';
import { Button, buttonVariants } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useAuth } from '../components/AuthProvider';
import { auth } from '../lib/firebase';
import { signOut } from 'firebase/auth';

export default function Home() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Auth Bar */}
      <div className="absolute top-4 right-4 z-50 flex gap-2">
        {user ? (
          <>
            <Link 
              to={profile?.role === 'super_admin' ? '/admin' : '/dashboard'}
              className={cn(buttonVariants({ variant: "ghost", size: "sm" }), "font-bold")}
            >
              <LayoutDashboard className="w-4 h-4 mr-2" />
              Dashboard
            </Link>
            <Button variant="ghost" size="sm" onClick={handleLogout} className="font-bold text-destructive">
              <LogOut className="w-4 h-4 mr-2" />
              Déconnexion
            </Button>
          </>
        ) : (
          <Link to="/login" className={cn(buttonVariants({ variant: "ghost", size: "sm" }), "font-bold")}>
            Connexion
          </Link>
        )}
      </div>

      {/* Hero Section */}
      <section className="relative py-20 px-6 overflow-hidden">
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-bold tracking-tight mb-6"
          >
            Le site web de votre <span className="text-primary">restaurant</span>, en toute simplicité
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10"
          >
            Offrez à vos clients une expérience de commande fluide et moderne. Gérez votre menu et vos commandes en temps réel avec une interface conçue pour les restaurateurs.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-wrap justify-center gap-4"
          >
            <Link 
              to={user ? (profile?.role === 'super_admin' ? '/admin' : '/dashboard') : "/login"} 
              className={cn(buttonVariants({ size: "lg" }), "flex items-center")}
            >
              Commencer maintenant <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
            <Link 
              to="/r/demo" 
              className={cn(buttonVariants({ size: "lg", variant: "outline" }), "flex items-center")}
            >
              Voir une démo
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-muted/30 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-12">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold">Simple & Rapide</h3>
              <p className="text-muted-foreground">Une interface pensée pour les restaurateurs : gérez vos commandes et votre carte sans aucune connaissance technique.</p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                <Store className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold">Votre Image</h3>
              <p className="text-muted-foreground">Personnalisez les couleurs, les photos et les informations de votre restaurant pour un site qui vous ressemble.</p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                <Utensils className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold">Commandes Directes</h3>
              <p className="text-muted-foreground">Recevez vos commandes instantanément sur votre tableau de bord et informez vos clients de la préparation.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
