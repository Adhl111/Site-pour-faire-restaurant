import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../components/AuthProvider';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, query, onSnapshot, doc, updateDoc, addDoc, deleteDoc } from 'firebase/firestore';
import { Restaurant, Order, MenuItem, Category, Reservation } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  ClipboardList, 
  Utensils, 
  Settings, 
  Power, 
  Clock, 
  AlertCircle,
  Plus,
  ChevronRight,
  ArrowLeft,
  ExternalLink,
  Save,
  Smartphone,
  Tablet,
  Monitor,
  Trash2,
  Calendar,
  User,
  Mail,
  Phone,
  MapPin,
  Check,
  X as XIcon
} from 'lucide-react';
import { cn } from '@/lib/utils';
import DirectPreview from '@/components/DirectPreview';
import { Textarea } from '@/components/ui/textarea';
import ImageUpload from '@/components/ImageUpload';

export default function Dashboard() {
  const { profile } = useAuth();
  const { restaurantId: urlRestaurantId } = useParams();
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [menu, setMenu] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'orders' | 'reservations' | 'menu' | 'settings'>('orders');
  
  // Form states
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [newItem, setNewItem] = useState<Partial<MenuItem>>({
    name: '',
    description: '',
    price: 0,
    category: 'pizza',
    image: 'https://picsum.photos/seed/food/400/300',
    available: true
  });
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [settingsForm, setSettingsForm] = useState({
    name: '',
    address: '',
    phone: '',
    description: '',
    heroImage: '',
    primaryColor: '#000000',
    secondaryColor: '#ffffff',
    accentColor: '#f43f5e',
    backgroundColor: '#ffffff',
    textColor: '#0f172a',
    logo: '',
    openingHours: '',
    fontFamily: 'sans' as 'sans' | 'serif' | 'mono',
    layoutStyle: 'modern' as 'modern' | 'classic' | 'elegant'
  });

  const [showPreview, setShowPreview] = useState(true);
  const [previewDevice, setPreviewDevice] = useState<'mobile' | 'tablet' | 'desktop'>('mobile');
  
  const effectiveRestaurantId = urlRestaurantId || profile?.restaurantId;

  useEffect(() => {
    if (!effectiveRestaurantId) {
      setLoading(false);
      return;
    }

    console.log('Dashboard: effectiveRestaurantId', effectiveRestaurantId);
    const unsubRes = onSnapshot(doc(db, 'restaurants', effectiveRestaurantId), (doc) => {
      console.log('Dashboard: restaurant snapshot', doc.exists());
      if (doc.exists()) {
        const data = { id: doc.id, ...doc.data() } as Restaurant;
        setRestaurant(data);
        setSettingsForm({
          name: data.name,
          address: data.config.address,
          phone: data.config.phone,
          description: data.description || '',
          heroImage: data.config.heroImage || '',
          primaryColor: data.config.primaryColor || '#000000',
          secondaryColor: data.config.secondaryColor || '#ffffff',
          accentColor: data.config.accentColor || '#f43f5e',
          backgroundColor: data.config.backgroundColor || '#ffffff',
          textColor: data.config.textColor || '#0f172a',
          logo: data.config.logo || '',
          openingHours: data.config.openingHours || '',
          fontFamily: data.config.fontFamily || 'sans',
          layoutStyle: data.config.layoutStyle || 'modern'
        });
      }
      setLoading(false);
    }, (error) => {
      console.error('Dashboard: restaurant error', error);
      handleFirestoreError(error, OperationType.GET, `restaurants/${effectiveRestaurantId}`);
      setLoading(false);
    });

    const qOrders = query(collection(db, `restaurants/${effectiveRestaurantId}/orders`));
    const unsubOrders = onSnapshot(qOrders, (snapshot) => {
      const ordersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
      setOrders(ordersData.sort((a, b) => b.createdAt?.toMillis() - a.createdAt?.toMillis()));
    }, (error) => handleFirestoreError(error, OperationType.LIST, `restaurants/${effectiveRestaurantId}/orders`));

    const qMenu = query(collection(db, `restaurants/${effectiveRestaurantId}/menu`));
    const unsubMenu = onSnapshot(qMenu, (snapshot) => {
      const menuData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as MenuItem));
      setMenu(menuData);
    }, (error) => handleFirestoreError(error, OperationType.LIST, `restaurants/${effectiveRestaurantId}/menu`));

    const qReservations = query(collection(db, `restaurants/${effectiveRestaurantId}/reservations`));
    const unsubReservations = onSnapshot(qReservations, (snapshot) => {
      const resData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reservation));
      setReservations(resData.sort((a, b) => b.createdAt?.toMillis() - a.createdAt?.toMillis()));
    }, (error) => handleFirestoreError(error, OperationType.LIST, `restaurants/${effectiveRestaurantId}/reservations`));

    return () => {
      unsubRes();
      unsubOrders();
      unsubMenu();
      unsubReservations();
    };
  }, [effectiveRestaurantId]);

  const toggleRestaurantStatus = async () => {
    if (!restaurant) return;
    try {
      await updateDoc(doc(db, 'restaurants', restaurant.id), {
        isOpen: !restaurant.isOpen
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `restaurants/${restaurant.id}`);
    }
  };

  const updateOrderStatus = async (orderId: string, status: Order['status'], waitingTime?: string) => {
    if (!restaurant) return;
    try {
      const updateData: any = { status };
      if (waitingTime) updateData.waitingTime = waitingTime;
      await updateDoc(doc(db, `restaurants/${restaurant.id}/orders`, orderId), updateData);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  const updateReservationStatus = async (resId: string, status: Reservation['status']) => {
    if (!restaurant) return;
    try {
      await updateDoc(doc(db, `restaurants/${restaurant.id}/reservations`, resId), { status });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `reservations/${resId}`);
    }
  };

  const handleAddItem = async () => {
    if (!restaurant || !newItem.name || !newItem.price) return;
    try {
      await addDoc(collection(db, `restaurants/${restaurant.id}/menu`), {
        ...newItem,
        restaurantId: restaurant.id,
        available: true
      });
      setIsAddingItem(false);
      setNewItem({
        name: '',
        description: '',
        price: 0,
        category: 'pizza',
        image: 'https://picsum.photos/seed/food/400/300',
        available: true
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `restaurants/${restaurant.id}/menu`);
    }
  };

  const handleUpdateItem = async () => {
    if (!restaurant || !editingItem) return;
    try {
      const { id, ...data } = editingItem;
      await updateDoc(doc(db, `restaurants/${restaurant.id}/menu`, id), data);
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `restaurants/${restaurant.id}/menu/${editingItem.id}`);
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    if (!restaurant) return;
    setDeletingItemId(itemId);
  };

  const [deletingItemId, setDeletingItemId] = useState<string | null>(null);

  const confirmDelete = async () => {
    if (!restaurant || !deletingItemId) return;
    try {
      await deleteDoc(doc(db, `restaurants/${restaurant.id}/menu`, deletingItemId));
      setDeletingItemId(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `restaurants/${restaurant.id}/menu/${deletingItemId}`);
    }
  };

  const toggleItemAvailability = async (item: MenuItem) => {
    if (!restaurant) return;
    try {
      await updateDoc(doc(db, `restaurants/${restaurant.id}/menu`, item.id), {
        available: !item.available
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `restaurants/${restaurant.id}/menu/${item.id}`);
    }
  };

  const handleSaveSettings = async () => {
    if (!restaurant) return;
    setIsSavingSettings(true);
    try {
      await updateDoc(doc(db, 'restaurants', restaurant.id), {
        name: settingsForm.name,
        description: settingsForm.description,
        'config.address': settingsForm.address,
        'config.phone': settingsForm.phone,
        'config.heroImage': settingsForm.heroImage,
        'config.primaryColor': settingsForm.primaryColor,
        'config.secondaryColor': settingsForm.secondaryColor,
        'config.accentColor': settingsForm.accentColor,
        'config.backgroundColor': settingsForm.backgroundColor,
        'config.textColor': settingsForm.textColor,
        'config.logo': settingsForm.logo,
        'config.openingHours': settingsForm.openingHours,
        'config.fontFamily': settingsForm.fontFamily,
        'config.layoutStyle': settingsForm.layoutStyle,
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `restaurants/${restaurant.id}`);
    } finally {
      setIsSavingSettings(false);
    }
  };

  const previewRestaurant = restaurant ? {
    ...restaurant,
    name: settingsForm.name,
    description: settingsForm.description,
    config: {
      ...restaurant.config,
      address: settingsForm.address,
      phone: settingsForm.phone,
      heroImage: settingsForm.heroImage,
      primaryColor: settingsForm.primaryColor,
      secondaryColor: settingsForm.secondaryColor,
      accentColor: settingsForm.accentColor,
      backgroundColor: settingsForm.backgroundColor,
      textColor: settingsForm.textColor,
      logo: settingsForm.logo,
      openingHours: settingsForm.openingHours,
      fontFamily: settingsForm.fontFamily,
      layoutStyle: settingsForm.layoutStyle
    }
  } : null;

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
    </div>
  );

  if (!effectiveRestaurantId) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center bg-slate-50">
        <div className="max-w-md space-y-4">
          <AlertCircle className="w-16 h-16 text-slate-300 mx-auto" />
          <h2 className="text-2xl font-bold text-slate-800">Configuration en cours</h2>
          <p className="text-slate-500">Votre espace sera prêt dès que l'administrateur aura finalisé la création de votre restaurant.</p>
        </div>
      </div>
    );
  }

  if (!restaurant) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center bg-slate-50">
        <div className="max-w-md space-y-4">
          <AlertCircle className="w-16 h-16 text-destructive mx-auto" />
          <h2 className="text-2xl font-bold text-slate-800">Restaurant non trouvé</h2>
          <p className="text-slate-500">Le restaurant demandé n'existe pas ou vous n'avez pas les droits pour y accéder.</p>
          <Link to="/admin">
            <Button variant="outline" className="mt-4">Retour à l'administration</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header ultra simple */}
      <header className="bg-white border-b sticky top-0 z-20 px-4 py-4">
        <div className="max-w-[1600px] mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            {urlRestaurantId && profile?.role === 'super_admin' && (
              <Link to="/admin" className="mr-2">
                <Button variant="ghost" size="icon" className="rounded-full">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
            )}
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary/20">
              <Utensils className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black leading-none">{restaurant?.name}</h1>
              </div>
              <div className="flex items-center gap-2 mt-1">
                {!import.meta.env.VITE_STANDALONE_RESTAURANT_SLUG && (
                  <Link to="/" className="text-[10px] font-black bg-slate-900 text-white px-2 py-1 rounded-md hover:bg-slate-700 transition-all flex items-center gap-1">
                    <ArrowLeft className="w-3 h-3" /> RETOUR PLATEFORME
                  </Link>
                )}
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Espace Client</p>
                <button 
                  onClick={() => setShowPreview(!showPreview)}
                  className="text-[10px] font-bold text-primary flex items-center hover:underline"
                >
                  {showPreview ? "Masquer l'aperçu" : "Afficher l'aperçu"}
                </button>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {restaurant?.customDomain ? (
              <a 
                href={`https://${restaurant.customDomain}`} 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button 
                  variant="ghost"
                  className="rounded-full px-3 md:px-6 h-12 font-black text-sm text-slate-500 hover:text-primary"
                >
                  <ExternalLink className="w-4 h-4 md:mr-2" />
                  <span className="hidden md:inline">VOIR LE SITE</span>
                </Button>
              </a>
            ) : (
              <Link to={import.meta.env.VITE_STANDALONE_RESTAURANT_SLUG ? "/" : `/r/${restaurant?.slug}`}>
                <Button 
                  variant="ghost"
                  className="rounded-full px-3 md:px-6 h-12 font-black text-sm text-slate-500 hover:text-primary"
                >
                  <ExternalLink className="w-4 h-4 md:mr-2" />
                  <span className="hidden md:inline">VOIR LE SITE</span>
                </Button>
              </Link>
            )}
            <Button 
              onClick={() => setActiveTab('settings')}
              variant="outline"
              className="hidden md:flex rounded-full px-6 h-12 font-black text-sm border-2"
            >
              <Settings className="w-4 h-4 mr-2" />
              MODIFIER LE SITE
            </Button>
            <Button 
              onClick={toggleRestaurantStatus}
              variant={restaurant?.isOpen ? "default" : "destructive"}
              className={cn(
                "rounded-full px-6 h-12 font-black text-sm transition-all active:scale-95 shadow-lg",
                restaurant?.isOpen ? "shadow-primary/20" : "shadow-destructive/20"
              )}
            >
              <Power className="w-4 h-4 mr-2" />
              {restaurant?.isOpen ? "OUVERT" : "FERMÉ"}
            </Button>
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Dashboard Controls */}
        <main className={cn(
          "flex-1 overflow-y-auto p-4 pb-24 transition-all duration-300",
          showPreview ? "md:max-w-[450px] lg:max-w-[500px] xl:max-w-[600px] border-r" : "max-w-4xl mx-auto"
        )}>
          <div className="space-y-6">
            {/* Navigation par gros boutons */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button 
                onClick={() => setActiveTab('orders')}
                className={cn(
                  "flex flex-col items-center gap-2 py-5 rounded-2xl transition-all border-2",
                  activeTab === 'orders' 
                    ? "bg-white border-primary text-primary shadow-xl shadow-primary/5" 
                    : "bg-white border-transparent text-slate-400 hover:border-slate-200"
                )}
              >
                <ClipboardList className={cn("w-6 h-6", activeTab === 'orders' ? "text-primary" : "text-slate-300")} />
                <span className="text-[10px] font-black uppercase tracking-widest">Commandes</span>
              </button>
              <button 
                onClick={() => setActiveTab('reservations')}
                className={cn(
                  "flex flex-col items-center gap-2 py-5 rounded-2xl transition-all border-2",
                  activeTab === 'reservations' 
                    ? "bg-white border-primary text-primary shadow-xl shadow-primary/5" 
                    : "bg-white border-transparent text-slate-400 hover:border-slate-200"
                )}
              >
                <Calendar className={cn("w-6 h-6", activeTab === 'reservations' ? "text-primary" : "text-slate-300")} />
                <span className="text-[10px] font-black uppercase tracking-widest">Résas</span>
              </button>
              <button 
                onClick={() => setActiveTab('menu')}
                className={cn(
                  "flex flex-col items-center gap-2 py-5 rounded-2xl transition-all border-2",
                  activeTab === 'menu' 
                    ? "bg-white border-primary text-primary shadow-xl shadow-primary/5" 
                    : "bg-white border-transparent text-slate-400 hover:border-slate-200"
                )}
              >
                <Utensils className={cn("w-6 h-6", activeTab === 'menu' ? "text-primary" : "text-slate-300")} />
                <span className="text-[10px] font-black uppercase tracking-widest">Carte</span>
              </button>
              <button 
                onClick={() => setActiveTab('settings')}
                className={cn(
                  "flex flex-col items-center gap-2 py-5 rounded-2xl transition-all border-2",
                  activeTab === 'settings' 
                    ? "bg-white border-primary text-primary shadow-xl shadow-primary/5" 
                    : "bg-white border-transparent text-slate-400 hover:border-slate-200"
                )}
              >
                <Settings className={cn("w-6 h-6", activeTab === 'settings' ? "text-primary" : "text-slate-300")} />
                <span className="text-[10px] font-black uppercase tracking-widest">Réglages</span>
              </button>
            </div>

            {/* Section Dynamique */}
            <div className="space-y-4">
              {activeTab === 'orders' && (
                <>
                  <div className="flex items-center justify-between px-2">
                    <h2 className="text-xl font-black text-slate-800">COMMANDES</h2>
                    <Badge className="bg-slate-200 text-slate-600 border-none font-black">{orders.length}</Badge>
                  </div>
                  
                  {orders.length === 0 ? (
                    <div className="bg-white rounded-3xl p-12 text-center border-2 border-dashed border-slate-200">
                      <ClipboardList className="w-12 h-12 text-slate-200 mx-auto mb-3" />
                      <p className="font-bold text-slate-400">En attente de commandes...</p>
                    </div>
                  ) : (
                    <div className="grid gap-4">
                      {orders.map(order => (
                        <Card key={order.id} className="border-none shadow-sm rounded-3xl overflow-hidden">
                          <CardContent className="p-0">
                            <div className="p-5 flex justify-between items-start">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="text-[10px] font-black bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full">
                                    #{order.id.slice(-4).toUpperCase()}
                                  </span>
                                  <span className="text-xs font-bold text-slate-400">
                                    {order.createdAt?.toDate().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                  </span>
                                </div>
                                <h3 className="text-2xl font-black">{order.total.toFixed(2)} €</h3>
                                {order.customerName && (
                                  <div className="mt-2 space-y-1">
                                    <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
                                      <User className="w-3 h-3" /> {order.customerName}
                                    </div>
                                    <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
                                      <Phone className="w-3 h-3" /> {order.customerPhone}
                                    </div>
                                  </div>
                                )}
                              </div>
                              <Badge className={cn(
                                "rounded-full px-3 py-1 font-black text-[10px]",
                                order.status === 'pending' ? "bg-amber-100 text-amber-600" : 
                                order.status === 'confirmed' ? "bg-blue-100 text-blue-600" : 
                                order.status === 'ready' ? "bg-green-100 text-green-600" : "bg-slate-100 text-slate-600"
                              )}>
                                {order.status.toUpperCase()}
                              </Badge>
                            </div>

                            <div className="px-5 pb-5 space-y-2">
                              {order.items.map((item, idx) => (
                                <div key={idx} className="flex justify-between text-sm font-bold text-slate-600">
                                  <span>{item.quantity}x {item.name}</span>
                                </div>
                              ))}
                            </div>

                            <div className="bg-slate-50 p-3 space-y-3">
                              {order.status === 'pending' && (
                                <div className="space-y-2">
                                  <div className="flex gap-2">
                                    <Input 
                                      placeholder="Temps d'attente (ex: 20 min)" 
                                      className="rounded-xl border-2 bg-white"
                                      id={`waiting-time-${order.id}`}
                                    />
                                    <Button 
                                      onClick={() => {
                                        const input = document.getElementById(`waiting-time-${order.id}`) as HTMLInputElement;
                                        updateOrderStatus(order.id, 'confirmed', input.value);
                                      }}
                                      className="bg-blue-600 hover:bg-blue-700 text-white font-black rounded-2xl h-10 px-6 shadow-lg shadow-blue-200"
                                    >
                                      ACCEPTER
                                    </Button>
                                  </div>
                                </div>
                              )}
                              {order.status === 'confirmed' && (
                                <div className="flex gap-2">
                                  <Button 
                                    onClick={() => updateOrderStatus(order.id, 'ready')}
                                    className="flex-1 bg-green-600 hover:bg-green-700 text-white font-black rounded-2xl h-14 shadow-lg shadow-green-200"
                                  >
                                    PRÊTE !
                                  </Button>
                                </div>
                              )}
                              {order.status === 'ready' && (
                                <div className="flex gap-2">
                                  <Button 
                                    onClick={() => updateOrderStatus(order.id, 'delivered')}
                                    className="flex-1 bg-slate-800 hover:bg-slate-900 text-white font-black rounded-2xl h-14 shadow-lg shadow-slate-200"
                                  >
                                    LIVRÉE
                                  </Button>
                                </div>
                              )}
                              {order.waitingTime && order.status !== 'pending' && (
                                <div className="px-2 py-1 bg-blue-50 text-blue-600 text-[10px] font-black rounded-lg inline-block">
                                  ATTENTE: {order.waitingTime}
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </>
              )}

              {activeTab === 'reservations' && (
                <>
                  <div className="flex items-center justify-between px-2">
                    <h2 className="text-xl font-black text-slate-800">RÉSERVATIONS</h2>
                    <Badge className="bg-slate-200 text-slate-600 border-none font-black">{reservations.length}</Badge>
                  </div>
                  
                  {reservations.length === 0 ? (
                    <div className="bg-white rounded-3xl p-12 text-center border-2 border-dashed border-slate-200">
                      <Calendar className="w-12 h-12 text-slate-200 mx-auto mb-3" />
                      <p className="font-bold text-slate-400">Aucune réservation...</p>
                    </div>
                  ) : (
                    <div className="grid gap-4">
                      {reservations.map(res => (
                        <Card key={res.id} className="border-none shadow-sm rounded-3xl overflow-hidden">
                          <CardContent className="p-5">
                            <div className="flex justify-between items-start mb-4">
                              <div>
                                <h3 className="text-xl font-black">{res.name}</h3>
                                <div className="flex items-center gap-4 mt-1">
                                  <div className="flex items-center gap-1 text-xs font-bold text-slate-500">
                                    <Calendar className="w-3 h-3" /> {res.date}
                                  </div>
                                  <div className="flex items-center gap-1 text-xs font-bold text-slate-500">
                                    <Clock className="w-3 h-3" /> {res.time}
                                  </div>
                                  <div className="flex items-center gap-1 text-xs font-bold text-slate-500">
                                    <User className="w-3 h-3" /> {res.guests} pers.
                                  </div>
                                </div>
                              </div>
                              <Badge className={cn(
                                "rounded-full px-3 py-1 font-black text-[10px]",
                                res.status === 'pending' ? "bg-amber-100 text-amber-600" : 
                                res.status === 'confirmed' ? "bg-green-100 text-green-600" : "bg-destructive/10 text-destructive"
                              )}>
                                {res.status.toUpperCase()}
                              </Badge>
                            </div>

                            <div className="space-y-2 mb-4">
                              <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
                                <Mail className="w-4 h-4 text-slate-300" /> {res.email}
                              </div>
                              {res.notes && (
                                <div className="p-3 bg-slate-50 rounded-xl text-xs font-bold text-slate-500 italic">
                                  "{res.notes}"
                                </div>
                              )}
                            </div>

                            <div className="flex gap-2">
                              {res.status === 'pending' && (
                                <>
                                  <Button 
                                    onClick={() => updateReservationStatus(res.id, 'confirmed')}
                                    className="flex-1 bg-green-600 hover:bg-green-700 text-white font-black rounded-2xl h-12"
                                  >
                                    <Check className="w-4 h-4 mr-2" /> ACCEPTER
                                  </Button>
                                  <Button 
                                    variant="outline"
                                    onClick={() => updateReservationStatus(res.id, 'cancelled')}
                                    className="flex-1 border-2 rounded-2xl h-12 font-bold text-destructive hover:bg-destructive/5"
                                  >
                                    <XIcon className="w-4 h-4 mr-2" /> REFUSER
                                  </Button>
                                </>
                              )}
                              {res.status === 'confirmed' && (
                                <Button 
                                  variant="outline"
                                  onClick={() => updateReservationStatus(res.id, 'cancelled')}
                                  className="flex-1 border-2 rounded-2xl h-12 font-bold text-slate-400"
                                >
                                  ANNULER
                                </Button>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </>
              )}

              {activeTab === 'menu' && (
                <>
                  <div className="flex items-center justify-between px-2">
                    <h2 className="text-xl font-black text-slate-800">MA CARTE</h2>
                    <Dialog open={isAddingItem} onOpenChange={setIsAddingItem}>
                      <DialogTrigger render={
                        <Button size="sm" className="rounded-full bg-primary font-black text-[10px] h-8 px-4">
                          <Plus className="w-3 h-3 mr-1" /> AJOUTER
                        </Button>
                      } />
                      <DialogContent className="sm:max-w-[425px] rounded-3xl">
                        <DialogHeader>
                          <DialogTitle className="text-2xl font-black">AJOUTER UN PLAT</DialogTitle>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Nom du plat</label>
                            <Input 
                              value={newItem.name} 
                              onChange={e => setNewItem({...newItem, name: e.target.value})}
                              placeholder="Ex: Pizza Margherita" 
                              className="rounded-xl border-2"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Prix (€)</label>
                              <Input 
                                type="number"
                                value={newItem.price} 
                                onChange={e => setNewItem({...newItem, price: parseFloat(e.target.value)})}
                                placeholder="12.50" 
                                className="rounded-xl border-2"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Catégorie</label>
                              <Select 
                                value={newItem.category} 
                                onValueChange={(v: Category) => setNewItem({...newItem, category: v})}
                              >
                                <SelectTrigger className="rounded-xl border-2">
                                  <SelectValue placeholder="Choisir" />
                                </SelectTrigger>
                                <SelectContent className="rounded-xl">
                                  <SelectItem value="pizza">Pizza</SelectItem>
                                  <SelectItem value="pasta">Pasta</SelectItem>
                                  <SelectItem value="antipasti">Antipasti</SelectItem>
                                  <SelectItem value="salade">Salade</SelectItem>
                                  <SelectItem value="risotto">Risotto</SelectItem>
                                  <SelectItem value="specialite">Spécialité</SelectItem>
                                  <SelectItem value="carne">Viande</SelectItem>
                                  <SelectItem value="pesce">Poisson</SelectItem>
                                  <SelectItem value="dolci">Dessert</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Description</label>
                            <Textarea 
                              value={newItem.description} 
                              onChange={e => setNewItem({...newItem, description: e.target.value})}
                              placeholder="Ingrédients, allergènes..." 
                              className="rounded-xl border-2 min-h-[100px]"
                            />
                          </div>
                          <div className="space-y-2">
                            <ImageUpload 
                              label="Image du plat"
                              value={newItem.image || ''} 
                              onChange={val => setNewItem({...newItem, image: val})}
                            />
                            <div className="flex items-center gap-2">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ou URL de l'image</label>
                              <Input 
                                value={newItem.image} 
                                onChange={e => setNewItem({...newItem, image: e.target.value})}
                                placeholder="https://images.unsplash.com/..." 
                                className="rounded-xl border-2 h-8 text-xs"
                              />
                            </div>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button onClick={handleAddItem} className="w-full h-14 rounded-2xl font-black text-lg">
                            AJOUTER À LA CARTE
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>

                  <div className="grid gap-3">
                    {menu.map(item => (
                      <div key={item.id} className="bg-white p-3 rounded-2xl shadow-sm flex items-center gap-4">
                        <img src={item.image} alt={item.name} className="w-16 h-16 rounded-xl object-cover bg-slate-100" />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-black text-slate-800 truncate">{item.name}</h4>
                          <p className="text-primary font-black text-sm">{item.price.toFixed(2)} €</p>
                        </div>
                        <div className="flex gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => setEditingItem(item)}
                            className="rounded-xl hover:bg-slate-100 text-slate-400"
                          >
                            <Settings className="w-5 h-5" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => toggleItemAvailability(item)}
                            className={cn("rounded-xl", item.available ? "text-green-500" : "text-slate-200")}
                          >
                            <Power className="w-5 h-5" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleDeleteItem(item.id)}
                            className="rounded-xl hover:bg-destructive/10 text-destructive/40 hover:text-destructive"
                          >
                            <Trash2 className="w-5 h-5" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Edit Item Dialog */}
                  <Dialog open={!!editingItem} onOpenChange={(open) => !open && setEditingItem(null)}>
                    <DialogContent className="sm:max-w-[425px] rounded-3xl">
                      <DialogHeader>
                        <DialogTitle className="text-2xl font-black">MODIFIER LE PLAT</DialogTitle>
                      </DialogHeader>
                      {editingItem && (
                        <div className="grid gap-4 py-4">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Nom du plat</label>
                            <Input 
                              value={editingItem.name} 
                              onChange={e => setEditingItem({...editingItem, name: e.target.value})}
                              className="rounded-xl border-2"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Prix (€)</label>
                              <Input 
                                type="number"
                                value={editingItem.price} 
                                onChange={e => setEditingItem({...editingItem, price: parseFloat(e.target.value)})}
                                className="rounded-xl border-2"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Catégorie</label>
                              <Select 
                                value={editingItem.category} 
                                onValueChange={(v: Category) => setEditingItem({...editingItem, category: v})}
                              >
                                <SelectTrigger className="rounded-xl border-2">
                                  <SelectValue placeholder="Choisir" />
                                </SelectTrigger>
                                <SelectContent className="rounded-xl">
                                  <SelectItem value="pizza">Pizza</SelectItem>
                                  <SelectItem value="pasta">Pasta</SelectItem>
                                  <SelectItem value="antipasti">Antipasti</SelectItem>
                                  <SelectItem value="salade">Salade</SelectItem>
                                  <SelectItem value="risotto">Risotto</SelectItem>
                                  <SelectItem value="specialite">Spécialité</SelectItem>
                                  <SelectItem value="carne">Viande</SelectItem>
                                  <SelectItem value="pesce">Poisson</SelectItem>
                                  <SelectItem value="dolci">Dessert</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Description</label>
                            <Textarea 
                              value={editingItem.description} 
                              onChange={e => setEditingItem({...editingItem, description: e.target.value})}
                              className="rounded-xl border-2 min-h-[100px]"
                            />
                          </div>
                          <div className="space-y-2">
                            <ImageUpload 
                              label="Image du plat"
                              value={editingItem.image || ''} 
                              onChange={val => setEditingItem({...editingItem, image: val})}
                            />
                            <div className="flex items-center gap-2">
                              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ou URL de l'image</label>
                              <Input 
                                value={editingItem.image} 
                                onChange={e => setEditingItem({...editingItem, image: e.target.value})}
                                className="rounded-xl border-2 h-8 text-xs"
                              />
                            </div>
                          </div>
                        </div>
                      )}
                      <DialogFooter>
                        <Button onClick={handleUpdateItem} className="w-full h-14 rounded-2xl font-black text-lg">
                          ENREGISTRER LES MODIFICATIONS
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  {/* Delete Confirmation Dialog */}
                  <Dialog open={!!deletingItemId} onOpenChange={(open) => !open && setDeletingItemId(null)}>
                    <DialogContent className="sm:max-w-[400px] rounded-3xl p-8">
                      <div className="text-center space-y-4">
                        <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center text-destructive mx-auto">
                          <Trash2 className="w-8 h-8" />
                        </div>
                        <div className="space-y-2">
                          <h3 className="text-xl font-black">Supprimer ce plat ?</h3>
                          <p className="text-slate-500 font-medium">Cette action est irréversible. Le plat sera retiré de votre carte.</p>
                        </div>
                        <div className="flex gap-3 pt-4">
                          <Button 
                            variant="outline" 
                            onClick={() => setDeletingItemId(null)}
                            className="flex-1 h-14 rounded-2xl font-bold"
                          >
                            ANNULER
                          </Button>
                          <Button 
                            variant="destructive" 
                            onClick={confirmDelete}
                            className="flex-1 h-14 rounded-2xl font-black shadow-lg shadow-destructive/20"
                          >
                            SUPPRIMER
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </>
              )}
              {activeTab === 'settings' && (
                <>
                  <h2 className="text-xl font-black text-slate-800 px-2">INFOS RESTAURANT</h2>
                  <div className="bg-white rounded-3xl p-6 shadow-sm space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Nom du restaurant</label>
                      <Input 
                        value={settingsForm.name} 
                        onChange={e => setSettingsForm({...settingsForm, name: e.target.value})}
                        className="h-14 rounded-2xl border-2 border-slate-100 font-bold focus:border-primary transition-all" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Description</label>
                      <Textarea 
                        value={settingsForm.description} 
                        onChange={e => setSettingsForm({...settingsForm, description: e.target.value})}
                        className="rounded-2xl border-2 border-slate-100 font-bold min-h-[100px]" 
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Police d'écriture</label>
                        <Select 
                          value={settingsForm.fontFamily} 
                          onValueChange={(v: any) => setSettingsForm({...settingsForm, fontFamily: v})}
                        >
                          <SelectTrigger className="h-14 rounded-2xl border-2 border-slate-100 font-bold">
                            <SelectValue placeholder="Choisir" />
                          </SelectTrigger>
                          <SelectContent className="rounded-2xl">
                            <SelectItem value="sans">Sans-Serif (Moderne)</SelectItem>
                            <SelectItem value="serif">Serif (Élégant)</SelectItem>
                            <SelectItem value="mono">Monospace (Technique)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Style de mise en page</label>
                        <Select 
                          value={settingsForm.layoutStyle} 
                          onValueChange={(v: any) => setSettingsForm({...settingsForm, layoutStyle: v})}
                        >
                          <SelectTrigger className="h-14 rounded-2xl border-2 border-slate-100 font-bold">
                            <SelectValue placeholder="Choisir" />
                          </SelectTrigger>
                          <SelectContent className="rounded-2xl">
                            <SelectItem value="modern">Moderne</SelectItem>
                            <SelectItem value="classic">Classique</SelectItem>
                            <SelectItem value="elegant">Épuré</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Couleur Principale</label>
                        <div className="flex gap-2">
                          <Input 
                            type="color"
                            value={settingsForm.primaryColor} 
                            onChange={e => setSettingsForm({...settingsForm, primaryColor: e.target.value})}
                            className="h-14 w-20 rounded-2xl border-2 border-slate-100 p-1" 
                          />
                          <Input 
                            value={settingsForm.primaryColor} 
                            onChange={e => setSettingsForm({...settingsForm, primaryColor: e.target.value})}
                            className="h-14 flex-1 rounded-2xl border-2 border-slate-100 font-mono" 
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Couleur Secondaire</label>
                        <div className="flex gap-2">
                          <Input 
                            type="color"
                            value={settingsForm.secondaryColor} 
                            onChange={e => setSettingsForm({...settingsForm, secondaryColor: e.target.value})}
                            className="h-14 w-20 rounded-2xl border-2 border-slate-100 p-1" 
                          />
                          <Input 
                            value={settingsForm.secondaryColor} 
                            onChange={e => setSettingsForm({...settingsForm, secondaryColor: e.target.value})}
                            className="h-14 flex-1 rounded-2xl border-2 border-slate-100 font-mono" 
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Accent</label>
                        <Input 
                          type="color"
                          value={settingsForm.accentColor} 
                          onChange={e => setSettingsForm({...settingsForm, accentColor: e.target.value})}
                          className="h-14 w-full rounded-2xl border-2 border-slate-100 p-1" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Fond</label>
                        <Input 
                          type="color"
                          value={settingsForm.backgroundColor} 
                          onChange={e => setSettingsForm({...settingsForm, backgroundColor: e.target.value})}
                          className="h-14 w-full rounded-2xl border-2 border-slate-100 p-1" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Texte</label>
                        <Input 
                          type="color"
                          value={settingsForm.textColor} 
                          onChange={e => setSettingsForm({...settingsForm, textColor: e.target.value})}
                          className="h-14 w-full rounded-2xl border-2 border-slate-100 p-1" 
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Téléphone</label>
                        <Input 
                          value={settingsForm.phone} 
                          onChange={e => setSettingsForm({...settingsForm, phone: e.target.value})}
                          className="h-14 rounded-2xl border-2 border-slate-100 font-bold" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Adresse</label>
                        <Input 
                          value={settingsForm.address} 
                          onChange={e => setSettingsForm({...settingsForm, address: e.target.value})}
                          className="h-14 rounded-2xl border-2 border-slate-100 font-bold" 
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <ImageUpload 
                        label="Logo du restaurant"
                        value={settingsForm.logo} 
                        onChange={val => setSettingsForm({...settingsForm, logo: val})}
                      />
                      <div className="flex items-center gap-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ou URL du logo</label>
                        <Input 
                          value={settingsForm.logo} 
                          onChange={e => setSettingsForm({...settingsForm, logo: e.target.value})}
                          placeholder="https://..."
                          className="h-8 rounded-xl border-2 border-slate-100 font-bold text-xs" 
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Horaires d'ouverture</label>
                      <Input 
                        value={settingsForm.openingHours} 
                        onChange={e => setSettingsForm({...settingsForm, openingHours: e.target.value})}
                        placeholder="Lun-Ven: 12h-14h, 19h-22h"
                        className="h-14 rounded-2xl border-2 border-slate-100 font-bold" 
                      />
                    </div>
                    <div className="space-y-2">
                      <ImageUpload 
                        label="Image d'accueil"
                        value={settingsForm.heroImage} 
                        onChange={val => setSettingsForm({...settingsForm, heroImage: val})}
                      />
                      <div className="flex items-center gap-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ou URL de l'image</label>
                        <Input 
                          value={settingsForm.heroImage} 
                          onChange={e => setSettingsForm({...settingsForm, heroImage: e.target.value})}
                          className="h-8 rounded-xl border-2 border-slate-100 font-bold text-xs" 
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Adresse</label>
                      <Input 
                        value={settingsForm.address} 
                        onChange={e => setSettingsForm({...settingsForm, address: e.target.value})}
                        className="h-14 rounded-2xl border-2 border-slate-100 font-bold" 
                      />
                    </div>
                    <Button 
                      onClick={handleSaveSettings}
                      disabled={isSavingSettings}
                      className={cn(
                        "w-full h-16 rounded-2xl font-black text-lg shadow-xl transition-all",
                        saveSuccess ? "bg-green-600 hover:bg-green-700 shadow-green-200" : "shadow-primary/20"
                      )}
                    >
                      {isSavingSettings ? "ENREGISTREMENT..." : saveSuccess ? "ENREGISTRÉ !" : "ENREGISTRER"}
                    </Button>
                  </div>
                </>
              )}
            </div>
          </div>
        </main>

        {/* Live Preview Pane */}
        {showPreview && (
          <aside className={cn(
            "hidden md:flex flex-col bg-slate-100 border-l overflow-hidden transition-all duration-300",
            previewDevice === 'desktop' ? "flex-[3]" : "flex-1"
          )}>
            <div className="p-4 border-b bg-white flex items-center justify-between shadow-sm z-30">
              <div className="flex items-center gap-4">
                <Badge className="bg-green-500 text-white border-none font-black px-3 py-1 shadow-sm animate-pulse">
                  EN DIRECT
                </Badge>
                <div className="flex bg-slate-100 p-1 rounded-xl">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setPreviewDevice('mobile')}
                    className={cn("rounded-lg h-8 px-3 transition-all", previewDevice === 'mobile' ? "bg-white shadow-sm text-primary" : "text-slate-400")}
                  >
                    <Smartphone className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setPreviewDevice('tablet')}
                    className={cn("rounded-lg h-8 px-3 transition-all", previewDevice === 'tablet' ? "bg-white shadow-sm text-primary" : "text-slate-400")}
                  >
                    <Tablet className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setPreviewDevice('desktop')}
                    className={cn("rounded-lg h-8 px-3 transition-all", previewDevice === 'desktop' ? "bg-white shadow-sm text-primary" : "text-slate-400")}
                  >
                    <Monitor className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => window.open(`/r/${restaurant.slug}`, '_blank')}
                  className="text-slate-500 font-bold hover:text-primary"
                >
                  <ExternalLink className="w-4 h-4 mr-2" /> Ouvrir
                </Button>
              </div>
            </div>
            
            <div className="flex-1 p-4 lg:p-8 flex items-center justify-center overflow-auto bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:20px_20px]">
               <div className={cn(
                 "bg-white shadow-2xl transition-all duration-500 overflow-hidden relative",
                 previewDevice === 'mobile' && "w-[375px] h-[667px] rounded-[3rem] border-[12px] border-slate-900",
                 previewDevice === 'tablet' && "w-[768px] h-[1024px] rounded-[2rem] border-[12px] border-slate-900 scale-[0.65] origin-center",
                 previewDevice === 'desktop' && "w-full h-full rounded-xl border-2 border-slate-200"
               )}>
                 {previewDevice === 'mobile' && <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-900 rounded-b-2xl z-20"></div>}
                 {previewRestaurant ? (
                   <DirectPreview 
                      restaurant={previewRestaurant} 
                      menu={menu} 
                      onEdit={(section) => {
                        if (section === 'menu') setActiveTab('menu');
                        else setActiveTab('settings');
                      }}
                    />
                 ) : (
                   <div className="w-full h-full flex flex-col items-center justify-center bg-slate-50 text-slate-400 gap-4">
                     <AlertCircle className="w-12 h-12 opacity-20" />
                     <p className="font-bold">Chargement de l'aperçu...</p>
                   </div>
                 )}
               </div>
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}
