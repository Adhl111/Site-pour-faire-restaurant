import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useConfig } from '../ConfigContext';
import { useAuth } from '../components/AuthProvider';
import { LayoutDashboard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import Menu from "../components/Menu";
import Reservation from "../components/Reservation";
import Footer from "../components/Footer";
import { getContrastColor } from '../lib/utils';

// Import Google Fonts dynamically
const FontLoader = () => (
  <style>
    {`
      @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,700;1,400&family=JetBrains+Mono:wght@400;700&display=swap');
    `}
  </style>
);

export default function RestaurantView() {
  const { slug } = useParams<{ slug: string }>();
  const { setSlug, isLoading, error, restaurant } = useConfig();
  const { profile } = useAuth();

  const canEdit = profile?.role === 'super_admin' || (profile?.role === 'restaurant_admin' && profile?.restaurantId === restaurant?.id);

  useEffect(() => {
    setSlug(slug || null);
    return () => setSlug(null);
  }, [slug, setSlug]);

  useEffect(() => {
    if (!restaurant) return;

    const config = (restaurant.config || {}) as any;
    const root = document.documentElement;

    if (config.primaryColor) {
      root.style.setProperty('--primary', config.primaryColor);
      root.style.setProperty('--primary-foreground', getContrastColor(config.primaryColor));
    }
    if (config.secondaryColor) {
      root.style.setProperty('--secondary', config.secondaryColor);
      root.style.setProperty('--secondary-foreground', getContrastColor(config.secondaryColor));
    }
    if (config.accentColor) {
      root.style.setProperty('--accent', config.accentColor);
      root.style.setProperty('--accent-foreground', getContrastColor(config.accentColor));
    }
    if (config.backgroundColor) {
      root.style.setProperty('--background', config.backgroundColor);
      root.style.setProperty('--foreground', getContrastColor(config.backgroundColor));
    }
    if (config.textColor) {
      root.style.setProperty('--foreground', config.textColor);
    }

    if (config.fontFamily) {
      const fonts = {
        sans: '"Inter", sans-serif',
        serif: '"Cormorant Garamond", serif',
        mono: '"JetBrains Mono", monospace'
      };
      const selectedFont = fonts[config.fontFamily as keyof typeof fonts] || fonts.sans;
      root.style.setProperty('--font-sans', selectedFont);
      root.style.setProperty('--font-heading', selectedFont);
    }

    return () => {
      root.style.removeProperty('--primary');
      root.style.removeProperty('--primary-foreground');
      root.style.removeProperty('--secondary');
      root.style.removeProperty('--secondary-foreground');
      root.style.removeProperty('--accent');
      root.style.removeProperty('--accent-foreground');
      root.style.removeProperty('--background');
      root.style.removeProperty('--foreground');
      root.style.removeProperty('--font-sans');
      root.style.removeProperty('--font-heading');
    };
  }, [restaurant]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error || !restaurant) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center">
        <h1 className="text-4xl font-bold mb-4">Oups !</h1>
        <p className="text-xl text-muted-foreground mb-8">{error || 'Restaurant non trouvé'}</p>
        <a href="/" className="text-primary hover:underline">Retour à l'accueil</a>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background selection:bg-primary/30">
      <FontLoader />
      <Navbar />
      <main>
        <Hero />
        <Menu />
        <Reservation />
      </main>
      <Footer />

      {/* Floating Edit Button for Admins */}
      {canEdit && (
        <div className="fixed bottom-8 right-8 z-50">
          <Link to={`/dashboard/${restaurant?.id}`}>
            <Button size="lg" className="rounded-full shadow-2xl font-black gap-2 h-14 px-8 border-4 border-white">
              <LayoutDashboard className="w-5 h-5" />
              MODIFIER LE SITE
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
