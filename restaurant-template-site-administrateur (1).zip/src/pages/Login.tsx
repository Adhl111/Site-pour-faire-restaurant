import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { LogIn } from 'lucide-react';

export default function Login() {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      
      // The AuthProvider will handle profile creation/fetch and redirect via App.tsx routing.
      // We don't need to navigate manually here, as it can cause race conditions 
      // where the profile isn't loaded yet.
    } catch (error) {
      console.error('Login error:', error);
      alert("Erreur lors de la connexion. Veuillez réessayer.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 px-6">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Connexion</CardTitle>
          <CardDescription>
            Connectez-vous pour gérer vos restaurants ou passer commande.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-6">
          <Button 
            onClick={handleGoogleLogin} 
            disabled={loading}
            className="w-full"
            size="lg"
          >
            <LogIn className="mr-2 h-5 w-5" />
            Continuer avec Google
          </Button>
        </CardContent>
        <CardFooter className="text-center text-sm text-muted-foreground">
          En vous connectant, vous acceptez nos conditions d'utilisation.
        </CardFooter>
      </Card>
    </div>
  );
}
