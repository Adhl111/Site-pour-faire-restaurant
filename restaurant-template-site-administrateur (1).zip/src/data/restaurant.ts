import { MenuItem, Restaurant } from "../types";

// This file now acts as a fallback or a place to export the types
// The actual data is loaded from Firestore

export const DEFAULT_RESTAURANT: Restaurant = {
  id: "default",
  ownerId: "system",
  slug: "demo",
  name: "Restaurant Démo",
  description: "Un exemple de restaurant sur notre plateforme.",
  config: {
    primaryColor: "#000000",
    logo: "",
    heroImage: "https://picsum.photos/seed/restaurant/1920/1080",
    address: "123 Rue de la Gastronomie, Paris",
    phone: "01 23 45 67 89",
    email: "contact@demo.fr",
    openingHours: "Lun-Sam: 12h-14h30, 19h-22h30",
    socials: {}
  },
  isOpen: true
};

export const DEFAULT_MENU: MenuItem[] = [];
