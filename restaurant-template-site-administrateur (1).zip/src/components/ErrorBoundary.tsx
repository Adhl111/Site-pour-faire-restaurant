import React, { Component, ErrorInfo, ReactNode } from "react";
import { AlertCircle, RefreshCw } from "lucide-react";
import { Button } from "./ui/button";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="min-h-[400px] flex flex-col items-center justify-center p-8 text-center bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
          <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-4">
            <AlertCircle className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black text-slate-800 mb-2">Oups ! Quelque chose a mal tourné.</h2>
          <p className="text-slate-500 mb-6 max-w-md">
            Une erreur inattendue est survenue lors de l'affichage de cette section.
          </p>
          <div className="bg-white p-4 rounded-xl border text-left mb-6 w-full max-w-lg overflow-auto max-h-40">
            <code className="text-xs text-red-500">{this.state.error?.toString()}</code>
          </div>
          <Button 
            onClick={() => window.location.reload()}
            className="rounded-full font-black gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            RECHARGER LA PAGE
          </Button>
        </div>
      );
    }

    return this.props.children;
  }
}
