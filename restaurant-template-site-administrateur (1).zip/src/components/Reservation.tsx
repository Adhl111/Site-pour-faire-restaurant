import { useState, FormEvent } from "react";
import { motion } from "motion/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, Users, Clock, CheckCircle2 } from "lucide-react";
import { useConfig } from "@/ConfigContext";
import { db, handleFirestoreError, OperationType } from "@/lib/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { Restaurant } from "@/types";

interface ReservationProps {
  restaurant?: Restaurant;
}

export default function Reservation({ restaurant: propRestaurant }: ReservationProps) {
  const config = useConfig();
  const restaurant = propRestaurant || config?.restaurant;
  const configLoading = propRestaurant ? false : config?.isLoading;
  
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  if (configLoading || !restaurant) return null;

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get("name"),
      email: formData.get("email"),
      date: formData.get("date"),
      time: formData.get("time"),
      guests: Number(formData.get("guests")),
      notes: formData.get("notes"),
      createdAt: serverTimestamp(),
      status: 'pending'
    };

    try {
      const path = `restaurants/${restaurant.id}/reservations`;
      await addDoc(collection(db, path), data);

      setIsSubmitted(true);
      // Reset after 10 seconds
      setTimeout(() => {
        setIsSubmitted(false);
      }, 10000);
    } catch (err) {
      console.error("Reservation error:", err);
      setError("Une erreur est survenue lors de la réservation. Veuillez réessayer.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="reservation" className="py-24 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-heading font-bold mb-6">Réserver votre table</h2>
            <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
              {restaurant.description}
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center shrink-0">
                  <Clock className="text-primary w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Horaires d'ouverture</h4>
                  <p className="text-muted-foreground">{restaurant.config.openingHours}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center shrink-0">
                  <Users className="text-accent w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Groupes & Événements</h4>
                  <p className="text-muted-foreground">Pour les groupes de plus de 10 personnes, merci de nous contacter directement par téléphone.</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <Card className="border-none shadow-2xl overflow-hidden">
              <div className="bg-primary p-6 text-primary-foreground text-center">
                <h3 className="text-2xl font-heading font-bold">Formulaire de Réservation</h3>
              </div>
              <CardContent className="p-8">
                {isSubmitted ? (
                  <motion.div 
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="text-center py-12"
                  >
                    <CheckCircle2 className="w-16 h-16 text-primary mx-auto mb-4" />
                    <h4 className="text-2xl font-bold mb-2">Merci !</h4>
                    <p className="text-muted-foreground">Votre demande de réservation a bien été reçue. Nous vous confirmerons la disponibilité par email sous peu.</p>
                  </motion.div>
                ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      {error && (
                        <div className="p-4 bg-destructive/10 border border-destructive/20 text-destructive rounded-xl text-sm font-medium">
                          {error}
                        </div>
                      )}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Nom complet</Label>
                          <Input id="name" name="name" placeholder="Mario Rossi" required className="rounded-xl" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input id="email" name="email" type="email" placeholder="mario@example.com" required className="rounded-xl" />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="date">Date</Label>
                          <div className="relative">
                            <Input id="date" name="date" type="date" required className="rounded-xl pl-10" />
                            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="time">Heure</Label>
                          <Input id="time" name="time" type="time" required className="rounded-xl" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="guests">Convives</Label>
                          <Input id="guests" name="guests" type="number" min="1" max="10" defaultValue="2" required className="rounded-xl" />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="notes">Notes spéciales (allergies, occasion...)</Label>
                        <Input id="notes" name="notes" placeholder="Optionnel" className="rounded-xl" />
                      </div>

                      <Button 
                        type="submit" 
                        disabled={isLoading}
                        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12 rounded-xl text-lg font-bold disabled:opacity-50"
                      >
                        {isLoading ? "Envoi en cours..." : "Confirmer la Réservation"}
                      </Button>
                    </form>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
