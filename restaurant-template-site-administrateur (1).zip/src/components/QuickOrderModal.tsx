import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Send, 
  CheckCircle2, 
  Clock, 
  Phone, 
  User,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MenuItem, Restaurant } from '@/types';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp, onSnapshot, doc } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firebase';

interface QuickOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: MenuItem | null;
  restaurant: Restaurant;
}

export default function QuickOrderModal({ isOpen, onClose, item, restaurant }: QuickOrderModalProps) {
  const [step, setStep] = useState<'form' | 'submitting' | 'waiting'>('form');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [orderId, setOrderId] = useState<string | null>(null);
  const [waitingTime, setWaitingTime] = useState<string | null>(null);
  const [status, setStatus] = useState<string>('pending');

  useEffect(() => {
    if (orderId && step === 'waiting') {
      const unsubscribe = onSnapshot(doc(db, `restaurants/${restaurant.id}/orders`, orderId), (doc) => {
        if (doc.exists()) {
          const data = doc.data();
          setStatus(data.status);
          if (data.waitingTime) {
            setWaitingTime(data.waitingTime);
          }
        }
      });
      return () => unsubscribe();
    }
  }, [orderId, step, restaurant.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!item || !name || !phone) return;

    setStep('submitting');
    try {
      const orderData = {
        restaurantId: restaurant.id,
        items: [{
          menuItemId: item.id,
          name: item.name,
          quantity: 1,
          price: item.price
        }],
        total: item.price,
        status: 'pending',
        customerName: name,
        customerPhone: phone,
        customerMessage: message,
        createdAt: serverTimestamp(),
      };

      const docRef = await addDoc(collection(db, `restaurants/${restaurant.id}/orders`), orderData);
      setOrderId(docRef.id);
      setStep('waiting');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'orders');
      setStep('form');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl relative"
      >
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-slate-100 rounded-full transition-colors z-10"
        >
          <X className="w-5 h-5 text-slate-400" />
        </button>

        {step === 'form' && (
          <div className="p-8">
            <div className="mb-6">
              <h2 className="text-2xl font-black text-slate-800 mb-2">Commander</h2>
              <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <img 
                  src={item?.image} 
                  alt={item?.name} 
                  className="w-12 h-12 rounded-xl object-cover"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <p className="font-bold text-slate-700">{item?.name}</p>
                  <p className="text-primary font-black">{item?.price.toFixed(2)} €</p>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Votre Nom</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                  <Input 
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="Jean Dupont"
                    className="pl-11 rounded-2xl border-2 h-12 focus:border-primary transition-all"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Téléphone</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                  <Input 
                    required
                    type="tel"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="06 12 34 56 78"
                    className="pl-11 rounded-2xl border-2 h-12 focus:border-primary transition-all"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Message (optionnel)</label>
                <Textarea 
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  placeholder="Précisions sur la commande..."
                  className="rounded-2xl border-2 min-h-[100px] focus:border-primary transition-all"
                />
              </div>

              <Button 
                type="submit"
                className="w-full h-14 rounded-2xl font-black text-lg shadow-xl shadow-primary/20 gap-2"
              >
                <Send className="w-5 h-5" />
                ENVOYER LA COMMANDE
              </Button>
            </form>
          </div>
        )}

        {step === 'submitting' && (
          <div className="p-12 text-center">
            <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto mb-4" />
            <h3 className="text-xl font-black text-slate-800">Envoi en cours...</h3>
          </div>
        )}

        {step === 'waiting' && (
          <div className="p-8 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10 text-green-600" />
            </div>
            
            <h3 className="text-2xl font-black text-slate-800 mb-2">Commande Envoyée !</h3>
            <p className="text-slate-500 font-medium mb-8">
              Le restaurateur a bien reçu votre message.
            </p>

            <div className="bg-slate-50 rounded-3xl p-6 border-2 border-dashed border-slate-200">
              {status === 'pending' ? (
                <div className="space-y-3">
                  <Clock className="w-8 h-8 text-amber-500 mx-auto animate-pulse" />
                  <p className="font-bold text-slate-600">En attente de confirmation...</p>
                  <p className="text-xs text-slate-400">Ne fermez pas cette fenêtre pour voir le temps d'attente.</p>
                </div>
              ) : status === 'confirmed' ? (
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full font-black text-sm">
                    COMMANDE CONFIRMÉE
                  </div>
                  {waitingTime ? (
                    <div className="space-y-1">
                      <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Temps d'attente estimé</p>
                      <p className="text-4xl font-black text-primary">{waitingTime}</p>
                    </div>
                  ) : (
                    <p className="font-bold text-slate-600">Le restaurateur prépare votre commande.</p>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="font-black text-slate-800 uppercase tracking-widest">{status.toUpperCase()}</p>
                  <p className="text-sm text-slate-500">Votre commande est en cours de traitement.</p>
                </div>
              )}
            </div>

            <Button 
              onClick={onClose}
              variant="ghost"
              className="mt-8 font-bold text-slate-400 hover:text-slate-600"
            >
              Fermer
            </Button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
