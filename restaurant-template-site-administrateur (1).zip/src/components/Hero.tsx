import { motion } from "motion/react";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useConfig } from "@/ConfigContext";
import { cn } from "@/lib/utils";
import { Restaurant } from "@/types";

interface HeroProps {
  restaurant?: Restaurant;
}

export default function Hero({ restaurant: propRestaurant }: HeroProps) {
  const config = useConfig();
  const restaurant = propRestaurant || config?.restaurant;

  if (!restaurant) return null;

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const layoutStyle = restaurant.config.layoutStyle || 'modern';

  return (
    <section id="hero" className={cn(
      "relative flex items-center justify-center overflow-hidden",
      layoutStyle === 'elegant' ? "min-h-[70vh] bg-slate-50" : "h-screen"
    )}>
      {/* Background Image with Overlay */}
      <div className={cn(
        "absolute inset-0 z-0",
        layoutStyle === 'elegant' ? "opacity-20 grayscale" : ""
      )}>
        <img 
          src={restaurant.config.heroImage} 
          alt={restaurant.name} 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        {layoutStyle !== 'elegant' && <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />}
      </div>

      <div className={cn(
        "relative z-10 text-center px-4 max-w-4xl",
        layoutStyle === 'elegant' ? "text-foreground" : "text-white"
      )}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className={cn(
            "font-heading font-bold mb-6 leading-[0.9]",
            layoutStyle === 'modern' ? "text-6xl md:text-8xl" : "text-5xl md:text-7xl",
            layoutStyle === 'elegant' ? "text-foreground" : "text-white"
          )}>
            {restaurant.name}
          </h1>
          <p className={cn(
            "text-lg md:text-xl mb-10 max-w-2xl mx-auto font-light leading-relaxed",
            layoutStyle === 'elegant' ? "text-muted-foreground" : "text-white/90"
          )}>
            {restaurant.description}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => scrollTo('menu')}
              className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 h-14 text-lg group"
            >
              Découvrir le Menu
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => scrollTo('reservation')}
              className={cn(
                "rounded-full px-8 h-14 text-lg backdrop-blur-md",
                layoutStyle === 'elegant' ? "border-border text-foreground hover:bg-secondary" : "bg-white/10 hover:bg-white/20 text-white border-white/30"
              )}
            >
              Réserver une Table
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
