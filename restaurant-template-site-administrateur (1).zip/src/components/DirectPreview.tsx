import React, { useEffect } from 'react';
import { Restaurant, MenuItem } from '../types';
import Navbar from './Navbar';
import Hero from './Hero';
import Menu from './Menu';
import Reservation from './Reservation';
import Footer from './Footer';
import { Edit2 } from 'lucide-react';
import { getContrastColor } from '../lib/utils';

interface DirectPreviewProps {
  restaurant: Restaurant;
  menu: MenuItem[];
  onEdit?: (section: 'hero' | 'menu' | 'settings' | 'reservation') => void;
}

export default function DirectPreview({ restaurant, menu, onEdit }: DirectPreviewProps) {
  // Apply fonts and colors locally for the preview
  useEffect(() => {
    if (!restaurant) return;

    const config = (restaurant.config || {}) as any;
    
    const previewContainer = document.getElementById('direct-preview-container');
    if (previewContainer) {
      if (config.primaryColor) {
        previewContainer.style.setProperty('--primary', config.primaryColor);
        previewContainer.style.setProperty('--primary-foreground', getContrastColor(config.primaryColor));
      }
      if (config.secondaryColor) {
        previewContainer.style.setProperty('--secondary', config.secondaryColor);
        previewContainer.style.setProperty('--secondary-foreground', getContrastColor(config.secondaryColor));
      }
      if (config.accentColor) {
        previewContainer.style.setProperty('--accent', config.accentColor);
        previewContainer.style.setProperty('--accent-foreground', getContrastColor(config.accentColor));
      }
      if (config.backgroundColor) {
        previewContainer.style.setProperty('--background', config.backgroundColor);
        previewContainer.style.setProperty('--foreground', getContrastColor(config.backgroundColor));
      }
      if (config.textColor) {
        previewContainer.style.setProperty('--foreground', config.textColor);
      }
      
      const fontMap = {
        sans: 'Inter, sans-serif',
        serif: "'Cormorant Garamond', serif",
        mono: "'JetBrains Mono', monospace"
      };
      
      if (config.fontFamily) {
        previewContainer.style.fontFamily = fontMap[config.fontFamily as keyof typeof fontMap] || fontMap.sans;
      }
    }
  }, [restaurant]);

  const EditButton = ({ section }: { section: 'hero' | 'menu' | 'settings' | 'reservation' }) => (
    <button 
      onClick={(e) => {
        e.stopPropagation();
        onEdit?.(section);
      }}
      className="absolute top-4 right-4 z-[100] bg-primary text-white p-2 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2 px-4 text-xs font-bold"
    >
      <Edit2 className="w-4 h-4" />
      MODIFIER
    </button>
  );

  return (
    <div id="direct-preview-container" className="w-full h-full overflow-y-auto bg-background text-foreground relative">
      <div className="relative group">
        <Navbar restaurant={restaurant} />
        <EditButton section="settings" />
      </div>
      <main>
        <div className="relative group">
          <Hero restaurant={restaurant} />
          <EditButton section="hero" />
        </div>
        <div className="relative group">
          <Menu restaurant={restaurant} menu={menu} />
          <EditButton section="menu" />
        </div>
        <div className="relative group">
          <Reservation restaurant={restaurant} />
          <EditButton section="reservation" />
        </div>
      </main>
      <div className="relative group">
        <Footer restaurant={restaurant} />
        <EditButton section="settings" />
      </div>
    </div>
  );
}
